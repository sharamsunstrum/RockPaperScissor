#include <iostream>


class Player{
    public:
int choice;


//methods
void Choice(int c,int ec, int number);
void ChoicePlayer(int choice,int enemyChoose);
void TextDisplay();
};